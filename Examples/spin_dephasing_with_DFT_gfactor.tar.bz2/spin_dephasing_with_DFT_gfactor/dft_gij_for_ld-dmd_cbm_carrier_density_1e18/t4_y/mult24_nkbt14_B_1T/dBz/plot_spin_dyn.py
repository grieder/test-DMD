#!/usr/bin/env python
import numpy as np
import matplotlib.pyplot as plt
import scipy.optimize

plt.rcParams["figure.titlesize"] = 22
plt.rcParams["lines.linewidth"] = 2
plt.rcParams["xtick.labelsize"] = 22
plt.rcParams["ytick.labelsize"] = 22
plt.rcParams["font.size"] = 22
#plt.rcParams["font.family"] = "sans-serif"
#plt.rcParams["font.sans-serif"] = "Arial"
plt.rcParams["legend.fontsize"] = 22
plt.rcParams["figure.figsize"] = (8, 6)
plt.rcParams["figure.dpi"] = 160

fin="sz_elec_tot.out"
tstart = 0 # ps
tend = np.inf # ps. if < 0, means +inf
Bfield = 1 # in-plane (for Sz) magnetic field in Tesla

t_data = np.loadtxt(fin,usecols=(0,))
nt = t_data.shape[0]
t_data = t_data * 2.4188843265857e-5 # / 40000. # a.u. to ps
mask = (t_data >= tstart) & (t_data <= tend)
t_data = t_data[mask]
print("Fitting range: [",t_data[0],", ",t_data[-1],"] ps")
t_data = t_data - t_data[0]
s_data = np.loadtxt(fin,usecols=(1,))[0:nt][mask]

# ==== theoretical parameter values ====
beta = 1 / 100. # initial guess of rate in 1/ps
Bfield = Bfield / 2.3505175675871e5 # convert to a.u.
omega = Bfield / 2.4188843265857e-5
phi = 0 # phase
params = beta, omega, phi

# ==== model ====
def decay(t, beta):
  s = s_data[0] * np.exp(-beta*t_data)
  return s
def decay_cosine(t, beta, omega, phi):
  s = s_data[0] * np.exp(-beta*t_data) * np.cos(omega*t_data + phi)
  return s
def residuals1(args, t, s):
  return s - decay(t, *args)
def residuals2(args, t, s):
  return s - decay_cosine(t, *args)

# ==== fitting using curve_fit ====
if omega == 0:
  params_cf, _ = scipy.optimize.curve_fit(decay, t_data, s_data)
  params_lsq, _ = scipy.optimize.leastsq(residuals1, beta, args=(t_data, s_data))
else:
  params_cf, _ = scipy.optimize.curve_fit(decay_cosine, t_data, s_data)
  params_lsq, _ = scipy.optimize.leastsq(residuals2, params, args=(t_data, s_data))

print("Global exponential fit by two ways:")
if omega == 0:
  print("cf: tau = ",1/params_cf[0]," ps")
  print("lsq: tau = ",1/params_lsq[0]," ps")
else:
  print("cf: tau = ",1/params_cf[0]," ps"," period = ",2*np.pi/params_cf[1],"ps"," phi = ",params_cf[2])
  print("lsq: tau = ",1/params_lsq[0]," ps"," period = ",2*np.pi/params_lsq[1],"ps"," phi = ",params_lsq[2])
  T = 1/params_lsq[1] # in ps
  larmor_freq = params_lsq[1]/(2*np.pi) # in ps^-1
  larmor_freq *= 4.135699 # in meV
  larmor_freq *= (1e-3 * 0.036749325247641719) # in Ha
  g = larmor_freq/Bfield*2
  print("g = {}".format(g))

if omega == 0:
  s_fit = decay(t_data, params_cf[0])
else:
  s_fit = decay_cosine(t_data, params_cf[0], params_cf[1], params_cf[2])

#log fit
s_data = np.log(np.abs(s_data))
nt = t_data.shape[0]
t1 = np.zeros(nt-1)
for it in range(2,nt+1):
  fit = np.polyfit(t_data[it-2:it],s_data[it-2:it],1)
  t1[it-2] = -1. / fit[0] # ps

#print("Log fit of time-resolved spin lifetime:")
#if nt-1 > 20:
#  print(t1[0:10])
#  print(t1[nt-11:nt-1])
#else:
#  print(t1)


fig, ax = plt.subplots(nrows=1, ncols=1, constrained_layout=True)

data = np.loadtxt("sfit.out")
time = data[:, 0]/1e3
calc_s = data[:, 1]
fit_s = data[:, 2]
#ax.plot(time[::3], calc_s[::3]/np.amax(np.abs(calc_s)), label="calc.", color='grey', alpha=0.33, zorder=0)
ax.plot(time, fit_s/np.amax(np.abs(fit_s)), label="fit", color="red", zorder=1)
ax.scatter(time[::3], calc_s[::3]/np.amax(np.abs(calc_s)), label="calc.", s=10, color='k', zorder=2)

ax.legend()
ax.set_xlim(np.amin(time), np.amax(time))
ax.set_ylim(-1, 1)
ax.set_xlabel("time (ns)")
ax.set_ylabel("S(t)")
plt.savefig("quality_of_s_fitting.png")
