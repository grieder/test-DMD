#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import os

plt.rcParams["figure.titlesize"] = 18
plt.rcParams["lines.linewidth"] = 3
plt.rcParams["xtick.labelsize"] = 18
plt.rcParams["ytick.labelsize"] = 18
plt.rcParams["font.size"] = 18
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["font.sans-serif"] = "Arial"
plt.rcParams["legend.fontsize"] = 18
plt.rcParams["figure.figsize"] = (4, 6)
plt.rcParams["figure.dpi"] = 100

cwd = os.getcwd()

fig, ax = plt.subplots(nrows=1, ncols=1, constrained_layout=True)



#### read kvec from ldbd_kvec.bin in ldbd_data folder
dir_ldbd_kvec = os.path.join(cwd, "ldbd_kvec.bin")
ldbd_kvec = np.fromfile(dir_ldbd_kvec, dtype=float, count=-1, sep="")
nk = int(len(ldbd_kvec)/3)
ldbd_kvec = ldbd_kvec.reshape(nk, 3)
weight = 1.0/nk
dt = np.dtype(
    {
        'names': ['f1', 'f2', 'f3', 'f4', 'f5'],
        'formats': ['<U20', float, float, float, float]
    }
)
data_to_save = np.empty(shape=(nk, 5), dtype=object)
#data_to_save = np.empty(nk, dtype=dt)
data_to_save[:, 0] = 'kpoint'
data_to_save[:, 1:4] = ldbd_kvec
data_to_save[:, 4] = weight

# write the uniform kpoints into a file
with open("bandstruct-uniform.kpoints", "w") as f:
    f.write("kpoint-folding 1 1 1  #To prevent accident folding in input file\n")
    f.write("symmetries none  #Necessary to prevent kpoint order / number from changing.\n")
    for i in range(nk):
         f.write("kpoint {0:21.14e} {1:21.14e} {2:21.14e} {3:21.14e}\n".format(ldbd_kvec[i, 0], ldbd_kvec[i, 1], ldbd_kvec[i, 2], weight))
#    np.savetxt(f, data_to_save)


