#!/usr/bin/env python3
import numpy as np
import os
import argparse

cwd = os.getcwd()

#### input ####
nk = 309
nb = 4
carrier = "e"
###############

# read g tensor
dir_gijexp = os.path.join(cwd, "gij.bin")
#dir_gijexp = os.path.join(cwd, "gijexp.bin")
gijexp = np.fromfile(dir_gijexp, dtype=float, count=-1, sep="")

# reshape g tensor
gijexp = gijexp.reshape(nk, nb, 3, 3)

if carrier == "h": # hole
    gijexp = gijexp[:, 0].reshape(nk, 9)
else: # electron
    gijexp = gijexp[:, 3].reshape(nk, 9)


# save g tensor
np.savetxt("g_tensor_k.dat", gijexp, header=" ")

