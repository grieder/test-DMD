#!/usr/bin/env python
from __future__ import print_function
import numpy as np
from numpy.linalg import norm
#import mpmath

kelvin2au = 1/3.157750248040761e5
ha2ev = 27.211386
bohr2cm = 0.52917720859e-8
au2second = 2.418884326505e-017
au2fs = 2.418884326505e-02

# Input parameters
dim = 3 # must be 2 or 3 now
label = '0' ; ni = np.array([])
#label = '1e11'
#ni = np.array([1e11]) # set to empty if no e-imp
for line in open('lindbladInit.out'):
  if "Effective interpolated k-mesh dimensions:" in line:
    tokens = line.split()
    kmesh = np.array([int(token) for token in tokens[5:8]])
    print("k meshes: ",kmesh)
    nk = np.prod(kmesh)

mu = np.arange(-1.0, 1.0, 0.01) / ha2ev # mu grids
#mu = np.arange(-0.2016, 0.1984, 0.01) / ha2ev # mu grids
t = 300 * kelvin2au # temperature
emid = 0 / ha2ev # assume the system is semiconductor and vbm < emid < cbm

#Read lattice vectors:
R = np.zeros((3,3))
iLine = 0
refLine = -10
for line in open('Wannier/totalE.out'):
  if line.find('Initializing the Grid') >= 0:
    refLine = iLine
  rowNum = iLine - (refLine+2)
  if rowNum>=0 and rowNum<3:
    R[rowNum,:] = [ float(x) for x in line.split()[1:-1] ]
  if rowNum==3:
    break
  iLine += 1
print("R:\n",R)

LxLy = np.cross(R[:,0], R[:,1])
Lz = norm(R[:,2])
vol = np.dot(R[:,2], LxLy) # volume
LxLy = norm(LxLy) # surface area
print("Surface area: ",LxLy)
print("Volume: ",vol)

# read data of energy, ImSigma with angle factors and velocity square along x, y, z
fsig = "ldbd_data/ldbd_imsigkn.out"
e = np.loadtxt(fsig, dtype=np.float64, usecols=(0,), skiprows=1)
imsig = np.loadtxt(fsig, dtype=np.float64, usecols=(1,), skiprows=1)
imsigp = np.loadtxt(fsig, dtype=np.float64, usecols=(2,), skiprows=1)
for i in range(ni.shape[0]):
  frac = ni[i] * (LxLy * bohr2cm**2)
  if dim == 3:
    frac = ni[i] * (vol * bohr2cm**3)
  print("fraction of impurities: ",frac)
  imsig = imsig + frac * np.loadtxt("ldbd_data/ldbd_imsigkn_D"+str(i+1)+".out", dtype=np.float64, usecols=(1,), skiprows=1)
  imsigp = imsigp + frac * np.loadtxt("ldbd_data/ldbd_imsigkn_D"+str(i+1)+".out", dtype=np.float64, usecols=(2,), skiprows=1)
v2 = np.loadtxt(fsig, dtype=np.float64, usecols=(4,5,6), skiprows=1)

# initialization
ne = np.zeros(mu.shape[0], dtype=np.float64)
nh = np.zeros(mu.shape[0], dtype=np.float64)
vvTau_e = np.zeros((mu.shape[0],3), dtype=np.float64)
vvTau_h = np.zeros((mu.shape[0],3), dtype=np.float64)
mob_e = np.zeros((mu.shape[0],3), dtype=np.float64)
mob_h = np.zeros((mu.shape[0],3), dtype=np.float64)
mob_avg = np.zeros((mu.shape[0],3), dtype=np.float64)

imsig_avg = np.zeros(mu.shape[0], dtype=np.float64)
tau_p_avg = np.zeros(mu.shape[0], dtype=np.float64) # direct average
imsigp_avg = np.zeros(mu.shape[0], dtype=np.float64)
tau_m_avg = np.zeros(mu.shape[0], dtype=np.float64) # direct average

# calculate mobility = sum df/de v^2 tau / n
for im in range(mu.shape[0]):
  f = 1. / (np.exp((e - mu[im])/t) + 1) # fermi-dirac
  dfde = f * (1-f) / t # actually -df/de
  sum_dfde = 0.
  for i in range(imsigp.shape[0]):
    if e[i] > emid: # electrons
      ne[im] = ne[im] + f[i]
      if imsigp[i] > 1e-40:
        vvTau_e[im] = vvTau_e[im] + dfde[i] * v2[i] / 2. / imsigp[i]
    else: # holes
      nh[im] = nh[im] + 1 - f[i]
      if imsigp[i] > 1e-40:
        vvTau_h[im] = vvTau_h[im] + dfde[i] * v2[i] / 2. / imsigp[i]
    sum_dfde = sum_dfde + dfde[i]
    imsig_avg[im] = imsig_avg[im] + dfde[i] * imsig[i]
    imsigp_avg[im] = imsigp_avg[im] + dfde[i] * imsigp[i]
    if imsig[i] > 1e-40:
      tau_p_avg[im] = tau_p_avg[im] + dfde[i] / 2. / imsig[i]
    if imsigp[i] > 1e-40:
      tau_m_avg[im] = tau_m_avg[im] + dfde[i] / 2. / imsigp[i]
  ne[im] = ne[im] / nk
  nh[im] = nh[im] / nk
  vvTau_e[im] = vvTau_e[im] / nk
  vvTau_h[im] = vvTau_h[im] / nk
  mob_e[im] = vvTau_e[im] / ne[im]
  mob_h[im] = vvTau_h[im] / nh[im]
  mob_avg[im] = (vvTau_e[im] + vvTau_h[im]) / (ne[im] + nh[im])
  imsig_avg[im] = imsig_avg[im] / sum_dfde
  imsigp_avg[im] = imsigp_avg[im] / sum_dfde
  tau_p_avg[im] = tau_p_avg[im] / sum_dfde
  tau_m_avg[im] = tau_m_avg[im] / sum_dfde

# switch to SI units
if dim == 3:
  ne = ne / vol / bohr2cm**3
  nh = nh / vol / bohr2cm**3
elif dim == 2:
  ne = ne / LxLy / bohr2cm**2
  nh = nh / LxLy / bohr2cm**2
mob_e = mob_e * bohr2cm**2 / ha2ev / au2second
mob_h = mob_h * bohr2cm**2 / ha2ev / au2second
mob_avg = mob_avg * bohr2cm**2 / ha2ev / au2second
imsig_avg = imsig_avg / au2fs
imsigp_avg = imsigp_avg / au2fs
tau_p_avg = tau_p_avg * au2fs
tau_m_avg = tau_m_avg * au2fs

# write to files
with open("mob_"+label+"_elec.out", "w") as fmob:
  fmob.write("#mu(eV), elec. dens.(cm-2),  mobility x y z (cm2/V/s)\n")
  np.savetxt(fmob,np.transpose([mu*ha2ev,ne,mob_e[:,0],mob_e[:,1],mob_e[:,2]]),fmt='%11.3e')
with open("mob_"+label+"_hole.out", "w") as fmob:
  fmob.write("#mu(eV), hole  dens.(cm-2),  mobility x y z (cm2/V/s)\n")
  np.savetxt(fmob,np.transpose([mu*ha2ev,nh,mob_h[:,0],mob_h[:,1],mob_h[:,2]]),fmt='%11.3e')
with open("mob_"+label+"_avg.out", "w") as fmob:
  fmob.write("#mu(eV), elec.+hole dens.(cm-2),  mobility x y z (cm2/V/s)\n")
  np.savetxt(fmob,np.transpose([mu*ha2ev,ne+nh,mob_avg[:,0],mob_avg[:,1],mob_avg[:,2]]),fmt='%11.3e')
with open("tau_p_or_m_"+label+".out", "w") as ftau:
  ftau.write("#mu(eV), tau_p (rate avg.), tau_p (time avg.), tau_m (rate avg.), tau_m (time avg.) (fs)\n")
  np.savetxt(ftau,np.transpose([mu*ha2ev,0.5/imsig_avg,tau_p_avg,0.5/imsigp_avg,tau_m_avg]),fmt='%11.3e')
