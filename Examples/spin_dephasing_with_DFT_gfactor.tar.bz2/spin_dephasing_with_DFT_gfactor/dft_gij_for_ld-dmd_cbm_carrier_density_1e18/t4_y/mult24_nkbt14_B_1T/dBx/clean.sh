#!/bin/bash
rm -r *out tau_t.dat restart debug_info ddm_along_kpath_results spin_mixing electron_analysis
