#!/usr/bin/env bash
#### https://stackoverflow.com/questions/8314499/read-n-lines-at-a-time-using-bash
# && ((${#ary[@]})) essentially means till there are lines to read (number of elements in the array return something)
#### https://askubuntu.com/questions/442914/calculating-the-number-of-lines-in-a-file
#### https://stackoverflow.com/questions/9533679/how-to-insert-a-text-at-the-beginning-of-a-file
#### https://unix.stackexchange.com/questions/222121/how-to-remove-a-column-or-multiple-columns-from-file-using-shell-command
#### https://unix.stackexchange.com/questions/117568/adding-a-column-of-values-in-a-tab-delimited-file



declare -i i=0
declare -i num_lines_per_file=100

while mapfile -t -n ${num_lines_per_file} ary && ((${#ary[@]}))
do
    ## remove the old files
    rm bandstruct.kpoints.$i
#    if [ $i != 0 ]
#    then
#        printf 'kpoint-folding 1 1 1  #To prevent accident folding in input file\n' >> bandstruct.kpoints.$i
#        printf 'symmetries none  #Necessary to prevent kpoint order / number from changing.\n' >> bandstruct.kpoints.$i
#    fi
    ## save the kpoints to file temp.$i
    printf '%s\n' "${ary[@]}" >> temp.$i
    printf -- '--- SNIP ---\n'
    i=$i+1
done < bandstruct-uniform.kpoints.sample


for k in $(seq 0 1 `echo $(($i-1))`)
do
    # count the number of line, i.e. the number of k points, in each file, and only display the count itself by piping that output by awk
    num_lines=`wc -l temp.${k} | awk '{ print $1 }'`
    # calc. weight
    weight=`awk -v var=${num_lines} "BEGIN {print (1.0/var)}"`
    # output the kpoints to bandstruct.kpoints.$k from temp.$k without weight
    awk '{print $1,$2,$3,$4}' temp.$k > bandstruct.kpoints.$k
    # remove temp.$i
    rm temp.$k
    # add the kpoints weight to the last column
    sed -i "s/$/\t${weight}/" bandstruct.kpoints.$k
    # add the following lines to the beginning of the files
    sed -i '1s+^+symmetries none  #Necessary to prevent kpoint order / number from changing.\n+' bandstruct.kpoints.$k
    sed -i '1s/^/kpoint-folding 1 1 1  #To prevent accident folding in input file\n/' bandstruct.kpoints.$k
done
