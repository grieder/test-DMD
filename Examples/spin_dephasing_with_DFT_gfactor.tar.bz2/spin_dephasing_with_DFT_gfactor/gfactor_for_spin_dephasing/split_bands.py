#!/usr/bin/env python
import numpy as np

nk1 = 16

kpts = np.loadtxt("bandstruct-uniform.kpoints",skiprows=2,usecols=(1,2,3)).reshape(-1,3)
nk = kpts.shape[0]
nrun = nk // nk1 + 1
ik0 = np.linspace(0, nk1*nrun, nrun+1, dtype=np.int)
ik0[nrun] = nk
print(ik0)

for irun in range(nrun):
  fname = "bandstruct.kpoints."+str(irun)
  weight = 1./(ik0[irun+1] - ik0[irun])
  with open(fname,"w") as f:
    f.write("kpoint-folding 1 1 1\n")
    f.write("symmetries none\n")
    for ik in range(ik0[irun], ik0[irun+1]):
      f.write("kpoint {0:21.14e} {1:21.14e} {2:21.14e} {3:21.14e}\n".format(kpts[ik,0],kpts[ik,1],kpts[ik,2],weight))
