#!/usr/bin/env python
from __future__ import print_function
import numpy as np
from numpy import linalg as LA
import scipy.optimize
import scipy.integrate as integrate
from scipy.optimize import fsolve
import sys
import os
from decimal import *

kelvin2au = 1/3.157750248040761e5
ha2ev = 27.211386
bohr2cm = 0.52917720859e-8
au2cm3 = np.power(bohr2cm,3)

T = 10 * kelvin2au # temperature
n = 4e18 * au2cm3 # carrier density from cm^-3 to a.u.
volume = 5617.89734915212745
kmesh = np.array([102,102,68])
nk = np.prod(kmesh)

ek_h = np.loadtxt("ek.out",usecols=(0,))
ek_e = np.loadtxt("ek.out",usecols=(2,))
gk_h = np.loadtxt("energy_change_B110.dat",usecols=(1,)) - np.loadtxt("energy_change_B110.dat",usecols=(0,))
gk_e = np.loadtxt("energy_change_B110.dat",usecols=(3,)) - np.loadtxt("energy_change_B110.dat",usecols=(2,))

def FD(e,mu_,carrier):
  if carrier == "e":
    return 1./(1 + np.exp((e - mu_) / T))
  else:
    return 1. - 1./(1 + np.exp((e - mu_) / T))

def solve_mu_e(mu_):
  occ = FD(ek_e,mu_,"e")
  sum_occ = np.sum(occ)
  result = 2 * sum_occ / volume / nk - n
  return result

def solve_mu_h(mu_):
  occ = FD(ek_h,mu_,"h")
  sum_occ = np.sum(occ)
  result = 2 * sum_occ / volume / nk - n
  return result

mu_h = fsolve(solve_mu_h, [ek_h[0]], xtol=1e-13)
mu_e = fsolve(solve_mu_e, [ek_e[0]], xtol=1e-13)
print("mu_h - VBM = ", mu_h - ek_h[0])
print("mu_e - CBM = ", mu_e - ek_e[0])

occ_e = FD(ek_e,mu_e,"e")
dfde_e = occ_e * (1. - occ_e)
occ_h = FD(ek_h,mu_h,"h")
dfde_h = occ_h * (1. - occ_h)

print(occ_e)
print(dfde_e)
print(occ_h)
print(dfde_h)

def calc_mean(a,dfde):
  return np.sum(a*dfde) / np.sum(dfde)

def calc_sigma(a,dfde):
  mean = calc_mean(a,dfde)
  sq = (a-mean)*(a-mean)
  return np.sqrt( np.sum(sq*dfde) / np.sum(dfde) )

print("mean of elec gk: ",calc_mean(gk_e,dfde_e))
print("sigma of elec gk: ",calc_sigma(gk_e,dfde_e))
print("mean of hole gk: ",calc_mean(gk_h,dfde_h))
print("sigma of hole gk: ",calc_sigma(gk_h,dfde_h))
