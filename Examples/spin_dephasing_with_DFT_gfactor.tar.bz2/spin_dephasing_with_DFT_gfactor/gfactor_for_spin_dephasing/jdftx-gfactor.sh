#!/bin/bash
#SBATCH --job-name=gfactor
#SBATCH --output=qe.%j
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=32
#SBATCH --time=24:00:00
#SBATCH --partition=cpuq
#SBATCH --dependency=afterany:1114308
#SBATCH --account=cpuq
# SBATCH --account=cfn311096

################################# Kairay #####################################
#module use /home/jxu153/modulefiles
#module load myopenmpi-4.0.2_gcc-4.8.5
#
#MPICMD="mpirun -np $SLURM_NTASKS"
#DIRJ="/export/data/share/jxu/jdftx_codes/jdftx-202209/build"
#DIRF="/export/data/share/jxu/jdftx_codes/jdftx-202209/build-FeynWann-mod"
##############################################################################

################################# Lux #####################################
module use /home/jxu153/modulefiles
module load myopenmpi-4.0.7_gcc gsl

#MPICMD="mpirun -n $SLURM_NTASKS --ppn 40"
#MPICMD="mpirun -np $SLURM_NTASKS"
MPICMD="mpirun -n $SLURM_NTASKS"
DIRJ="/data/groups/ping/jxu153/codes/jdftx/jdftx-202201/build"
DIRF="/data/groups/ping/jxu153/codes/jdftx/jdftx-202201/build-FeynWann/"
##############################################################################

#################################### BNL #####################################
# module load intel 
# module load python/3.8-anaconda-2020-11
# echo "Start:"; date
# export OMP_NUM_THREADS=1
# MPICMD="srun -n $SLURM_NTASKS"
#
# DIRJ="/sdcc/u/kli/programs/jdftx/build"
##############################################################################

#${MPICMD} ${DIRJ}/jdftx -i dump.in > totalE.out

### uncomment this when needing to split k points to speed up calculation
for i in {17..19}
do
    ${MPICMD} ${DIRJ}/jdftx -i dump.in.$i > totalE.out.$i
done

#i=XX
#${MPICMD} ${DIRJ}/jdftx -i dump.in.$i > totalE.out.$i

