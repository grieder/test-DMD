#!/bin/bash
for what in eigenvals S momenta L; do
  for i in {0..19}; do
    cat totalE.${i}.${what} >> totalE.${what}
  done
done
