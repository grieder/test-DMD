#!/usr/bin/env bash

rm totalE.out.* qe*
