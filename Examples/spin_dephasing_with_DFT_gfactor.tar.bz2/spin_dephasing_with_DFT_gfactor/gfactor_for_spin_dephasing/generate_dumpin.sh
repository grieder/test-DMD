#!/bin/bash
# do this when needing to split k points to speed up calculation
#for i in {0..20}; do
for i in {0..19}; do
  cp dump.in dump.in.$i
  sed -i "s/XX/${i}/g" dump.in.$i
done
