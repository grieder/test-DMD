#!/usr/bin/env python
import numpy as np

nb = 4
b = 2

g = np.fromfile('gij.bin',np.float64).reshape(-1,nb,3,3)
gexp = np.fromfile('gijexp.bin',np.float64).reshape(-1,nb,3,3)

np.savetxt('g_tensor_k.dat', g[:,b].reshape(-1,9), fmt='%14.10lf', header='gfack:')
np.savetxt('gexp_tensor_k.dat', gexp[:,b].reshape(-1,9), fmt='%14.10lf', header='gfack:')

b = 1

np.savetxt('g_tensor_k_hole.dat', g[:,b].reshape(-1,9), fmt='%14.10lf', header='gfack:')
np.savetxt('gexp_tensor_k_hole.dat', gexp[:,b].reshape(-1,9), fmt='%14.10lf', header='gfack:')



'''
e = np.transpose(np.loadtxt("ek.out"))
eh = 0.5*(e[1] + e[0])
eh = (eh[0] - eh)*27211.386
ee = 0.5*(e[3] + e[2])
ee = (ee - ee[0])*27211.386

spin_sign = np.transpose(np.sign(np.loadtxt("angular_momenta_diag_Bz.dat", usecols=(5,7))))
de = np.transpose(np.loadtxt("energy_change_Bz.dat"))
gexp = np.zeros((2,g.shape[0]))
gexp[0] = de[1] - de[0]
gexp[1] = de[2] - de[3]
gexp = spin_sign * gexp
np.savetxt("gexp.dat", np.transpose([eh, gexp[0], ee, gexp[1]]), header="hole E (meV), hole g^exp, elec E (meV), elec g^exp")
'''
