#!/usr/bin/env python
from __future__ import print_function
import numpy as np
from numpy import linalg as LA
import re
import os
import sys

# The script computes orbital angnular momentum matrix L from momentum matrix p and energies computed by JDFTx code
# and output L to totalE.L.
# It also compute k-dependent g tensors of selected bands
# and check whether g tensors lead to correct magnetic-field-induced splittings

# Input paramters
dir_p = "./" # directory having totalE.momenta with more bands
             # dir_p should also have totalE.eigenvals and totalE.out
dir_s = "./" # directory having totalE.S with less bands or the same bands as totalE.momenta
             # band number is read from dir_s+'/totalE.out'
             # dir_s can be the same as dir_p
bstart_g = 0 # band range for g factor analysis
bend_g = 0 #
Bmag = 0.001 # the magnitude of test magnetic field in Tesla
           # from energy changes induced by a magnetic field, we can analyse g factors
Bdir = np.array([1,0,0]) # direction of magnetic field
nb_l = 0 # number of bands for L. If <= 0, will be reset to number of bands for spin
nk_g = 0 # number of k points for g factor If <= 0, will be reset to number of k points for L
degthr = 1e-10 # degeneracy threshold
groupthr = 1e-10 # if energy difference < 1e-10, bands form a group. g factor tensor is defined for a group
Kramers = True # assume Kramers' degeneracy
#scissor = 0 # According to PHYSICAL REVIEW RESEARCH 2, 033256 (2020), self-energy effects can not described by a simple scissor

print('degeneracy threshold: ',degthr)
print('groupthr (if energy difference < groupthr, bands form a group. g factor tensor is defined for a group):\n',groupthr)
print('Has Kramers degeneracy? ',Kramers)

##################################################
# Obtain orbital angular momenta L matrices
##################################################

##################################################
# Step 1: Read totalE.out and energies
##################################################
# Read totalE.out and set sizes
def read_totalE_out(dir_):
  SOC = False
  for line in open(dir_+"totalE.out"):
    if "nBands" in line:
      nelec = int(float(re.findall(r"[+-]?\d+\.\d*", line)[0]))
      nb = int(re.findall(r"[+-]?\d+\.\d*|[+-]?\d+", line)[1])
      nk = int(re.findall(r"[+-]?\d+\.\d*|[+-]?\d+", line)[2])
    if "spintype spin-orbit" in line or "spintype vector-spin" in line:
      SOC = True
  return nk, nb, nelec, SOC

nk, nb_p, bCBM, SOC = read_totalE_out(dir_p)
print("number of k points: ",nk)
if nk_g <= 0:
  nk_g = nk
elif nk_g > nk:
  print("number of k points for g > number of bands for L")
  exit(1)
print("number of bands for momenta: ",nb_p)
nk_s, nb_s, _, _ = read_totalE_out(dir_s)
if nk != nk_s:
  print("numbers of k points are not the same")
  exit(1)
print("number of bands for spin: ",nb_s)
if nb_l <= 0:
  nb_l = nb_s
elif nb_l > nb_s:
  print("number of bands for L > number of bands for spin")
  exit(1)
print("number of bands for L: ",nb_l)
if not SOC:
  bCBM = bCBM // 2
if bend_g <= bstart_g:
  bstart_g = max(bCBM - 2, 0)
  bend_g = min(bCBM + 2, nb_l)
print("number of valence bands (if semiconductor): ", bCBM)
print("band range for g-factor analysis: ",bstart_g," ",bend_g)
sys.stdout.flush()

# Read energies e
e = np.fromfile(dir_p+"totalE.eigenvals",np.float64).reshape(nk,nb_p)
if Kramers:
  e[:,0:nb_p:2] = 0.5 * (e[:,0:nb_p:2] + e[:,1:nb_p:2])
  e[:,1:nb_p:2] = e[:,0:nb_p:2]
np.savetxt('ek.out', e[:,bstart_g:bend_g])

##################################################
# Step 2: Read / Compute L = r X p 
##################################################
def apply_Kramers(M):
  for ik in range(nk):
    ib = 0
    while ib < M.shape[-1]:
      jb = ib + 1
      while jb < M.shape[-1]:
        if abs(e[ik,ib] - e[ik,jb]) > degthr:
          break
        jb = jb + 1
      if jb - ib == 2:
        M[ik,ib,ib] = M[ik,ib,ib] - 0.5*(M[ik,ib+1,ib+1]+M[ik,ib,ib])
        M[ik,ib+1,ib+1] = -M[ik,ib,ib]
      elif (jb-ib) % 2 != 0:
        print('the size of degenerate subspace is odd')
        exit(1)
      ib = jb

# check Hermitian errors of a matrix
def check_Hermitian(M,s):
  if M.shape[-1] != M.shape[-2]:
    return
  print("\nCheck Hermitian errors of matrix "+s)
  err = np.abs(M - 0.5*(M + M.swapaxes(2,3).conj()))
  print("max Hermitian error: ",np.amax(err))
  print("indices for max Hermitian error: ",np.unravel_index(np.argmax(err, axis=None), err.shape))
  err_g = err[:,:,bstart_g:bend_g,bstart_g:bend_g]
  print("max Hermitian error in a small space from bstart_g to bend_g: ",np.amax(err_g))
  print("indices for max Hermitian error in the small space: ",np.unravel_index(np.argmax(err_g, axis=None), err_g.shape))
  print("")

# read momentum matrix p
if os.path.isfile("totalE.momenta"):
  p = np.fromfile(dir_p+"totalE.momenta",np.complex128).reshape(nk,3,nb_p,nb_p).swapaxes(2,3) # from Fortran to C
else:
  p = np.zeros((nk,3,nb_p,nb_p),np.complex128)
check_Hermitian(p,"p")
p = 0.5*(p + p.swapaxes(2,3).conj())
if Kramers:
  for idir in range(3):
    apply_Kramers(p[:,idir])

if os.path.isfile("totalE.L"):
  print("read L from totalE.L")
  L = np.fromfile(dir_p+"totalE.L",np.complex128).reshape(nk,3,nb_l,nb_l).swapaxes(2,3) # from Fortran to C
else:
  print("compute L = r X p")
    
  # compute r matrix. r_mn = -i p_mn / (e_m - e_n) with e_m - e_m != 0
  r = np.copy(p[:,:,0:nb_l,0:nb_p])
  for ik in range(nk):
    for idir in range(3):
      for ib in range(nb_l):
        for jb in range(nb_p):
          if (abs(e[ik,ib] - e[ik,jb]) > degthr):
            r[ik,idir,ib,jb] = p[ik,idir,ib,jb] / (e[ik,ib] - e[ik,jb]) # without prefactor -i
  r = -1j * r
  check_Hermitian(r,"r")
  if nb_l == nb_p:
    r = 0.5*(r + r.swapaxes(2,3).conj())
  
  # L = r X p
  L = np.zeros((nk_s,3,nb_l,nb_l),np.complex128)
  L[:,0] = np.einsum("kab,kbc->kac", r[:,1], p[:,2,0:nb_p,0:nb_l]) - np.einsum("kab,kbc->kac", r[:,2], p[:,1,0:nb_p,0:nb_l])
  L[:,1] = np.einsum("kab,kbc->kac", r[:,2], p[:,0,0:nb_p,0:nb_l]) - np.einsum("kab,kbc->kac", r[:,0], p[:,2,0:nb_p,0:nb_l])
  L[:,2] = np.einsum("kab,kbc->kac", r[:,0], p[:,1,0:nb_p,0:nb_l]) - np.einsum("kab,kbc->kac", r[:,1], p[:,0,0:nb_p,0:nb_l])
  check_Hermitian(L,"L")
  L = 0.5*(L + L.swapaxes(2,3).conj())
  if Kramers:
    for idir in range(3):
      apply_Kramers(L[:,idir])
  L.swapaxes(2,3).tofile("totalE.L") # from C to Fortran for JDFTx

for idir in range(3):
  print("Along idir ",idir)
  np.savetxt(sys.stdout, L[0,idir,bstart_g:bend_g,bstart_g:bend_g], fmt="%.1le")

##################################################
# Analysis g factor
##################################################

# Analysis 1: Define g tensor from L^deg, S^deg matrices
# "deg" means degenerate projection (can be relaxed to a larger energy threshold if degeneracy is broken a little).
# Assuming the studied degenerate subspace is separated from other bands,
# energy splitting and dynamics under B field are mostly determined by L^deg and S^deg instead of full L and S.
# In degenerate subspace, suppose Li+gs*Si = gij Sj,
# we have Tr[(Li+gs*Si) Sk] = Tr[gij Sj Sk], k=x,y,z.
# gij can be then solved

# Analysis 2: Experimentally, g factors are defined by energy splitting
# Define g factor for band 1 and 2 as 
# 0.5 g_{i,12} B_i = Delta(E_2 - E_1)
# = [E_2(B_i) - E_1(B_i)] - [E_2(B_i=0) - E_1(B_i=0)] (suppose the band ordering is not changed),
# so g_{i,12} = Delta(E_2 - E_1) / (0.5 * B_i).
# In 1st order perturbation, g_{i,12} = (L+gs*S)^{exp}_{i,2} - (L+gs*S)^{exp}_{i,1},
# where exp means expectation value.

print('\nAnalyse g factor for bands in range:',bstart_g,bend_g)

# JDFTx spin matrix is <1|pauli|2> without 0.5 factor
if SOC:
  S = 0.5 * np.fromfile(dir_s+"totalE.S",np.complex128).reshape(nk_s,3,nb_s,nb_s).swapaxes(2,3)[:,:,0:nb_l,0:nb_l] # from Fortran to C
else:
  S = np.zeros((nk_s,3,nb_l,nb_l),np.complex128)
gs = 2.0023193043625635

##################################################
# Analysis 1: Solve g tensor
##################################################
if SOC:
  print('Solve g tensor:')
  
  # Open files and write comments
  f_g_tensor = open("g_tensor.out", "w")
  f_g_tensor.write('#g tensor from Tr[(Li+gs*Si) Sk] = Tr[gij Sj Sk], k=x,y,z\n')
  f_g_tensor.write('#Band range: %4s %4s\n' % (bstart_g, bend_g))
  
  gij = np.zeros((nk_g,bend_g-bstart_g,3,3), np.float64)
  gijexp = np.zeros((nk_g,bend_g-bstart_g,3,3), np.float64)
  
  for ik in range(nk_g):
    print('#At ik = ',ik,':')
    # Determine a "degenerate" subspace with bands separated far from other bands
    ib = bstart_g
    while ib < bend_g:
      if ib == bstart_g:
        jb = ib - 1
        while jb > -1:
          if abs(e[ik][jb] - e[ik][ib]) > groupthr:
            break
          jb = jb - 1
        bstart_deg = jb + 1
      else:
        bstart_deg = ib
      jb = ib + 1
      while jb < nb_l:
        if abs(e[ik][jb] - e[ik][ib]) > groupthr:
          break
        jb = jb + 1
      bend_deg = jb
      if Kramers and (bend_deg - bstart_deg) % 2 != 0:
        print("size of degenerate subspace is odd")
        exit(1)
      print("bstart_deg = ",bstart_deg," bend_deg",bend_deg)
      # Degeneracy projection
      Sdeg = S[ik,:,bstart_deg:bend_deg,bstart_deg:bend_deg]
      Ldeg = L[ik,:,bstart_deg:bend_deg,bstart_deg:bend_deg]
      # Solve Tr[(Li+gs*Si) Sk] = Tr[gij Sj Sk], k=x,y,z
      # Compute traces
      trace_ss = np.zeros((3,3),np.float64)
      for kdir in range(3):
        for jdir in range(3):
          trace_ss[kdir,jdir] = np.einsum("ab,ba",Sdeg[jdir],Sdeg[kdir]).real
      #print("Tr[Sj Sk] = \n",trace_ss)
      for idir in range(3):  
        trace_ = np.einsum("ab,kba->k",Ldeg[idir]+gs*Sdeg[idir],Sdeg).real
        #print("For Dir ",idir," Tr[(Li+gs*Si) Sk] = ",trace_)
        # Solve gij
        if LA.det(trace_ss) < 1e-10:
          gij[ik,(ib-bstart_g):(min(bend_g,bend_deg)-bstart_g),idir,idir] = trace_[idir] / trace_ss[idir,idir]
        else:  
          gij[ik,(ib-bstart_g):(min(bend_g,bend_deg)-bstart_g),idir] = LA.solve(trace_ss, trace_)
      # Solve gijexp
      for idir in range(3):  
        gS = Ldeg[idir]+gs*Sdeg[idir]
        eig, U = LA.eigh(gS)
        Sexp = np.einsum("ba,ibc,ca->ia", U.conj(), Sdeg, U)
        Sexpabs = LA.norm(Sexp, axis=0)
        for kb in range(bstart_deg,bend_deg):
        	for jdir in range(3):
        	  gijexp[ik,kb-bstart_g,idir,jdir] = 2 * eig[kb-bstart_deg] * Sexp[jdir,kb-bstart_deg] / Sexpabs[kb-bstart_deg]
      ib = jb
    # Output gij
    f_g_tensor.write('\n#At ik = %d:\n\n' % (ik))
    np.savetxt(f_g_tensor, gij[ik].reshape(-1,9), fmt='%.4f')
  
  f_g_tensor.close()
  gij.tofile("gij.bin")
  gijexp.tofile("gijexp.bin")
  sys.stdout.flush()

##################################################
# Analysis 2: Apply magnetic fields
##################################################
print('Apply magnetic fields')

# Test magnetic fields
print('Magnitude of B field: ',Bmag,' Tesla')
Bmag = Bmag / 2.3505175675871e5 # convert to atomic unit
Bdir_ = np.eye(4,3)
Bdir_[3] = Bdir / LA.norm(Bdir)
print('Directions of B fields:\n',Bdir_)

Alc = np.array([1,-1j,0], np.complex128)
Arc = np.array([1,1j,0], np.complex128)

# Open files and write comments
f_de = open("energy_change_Bext.out", "w")
f_de.write('#Energy changes induced by Bext at different k divided by 0.5 * B_i\n')
f_de.write('#g factor for band 1 and 2 is g_{i,12} = [ Delta E_2(B_i) - Delta E_1(B_i) ] / (0.5 * B_i)\n')
f_de.write('#Band range: %4s %4s\n' % (bstart_g, bend_g))
f_AM_diag = open("angular_momenta_diag.out", "w")
f_AM_diag.write('#Diagonal elements of L, S and L+gs*S at different k with gs=2.0023\n')
f_AM_diag.write('#g factor for band 1 and 2 is g_{i,12} = (L+gs*S)^{exp}_{i,2} - (L+gs*S)^{exp}_{i,1}\n')
f_AM_diag.write('#Band range: %4s %4s\n' % (bstart_g, bend_g))
f_de_test = open("energy_change_Appr_Zeeman.out", "w")
f_de_test.write('#Energy changes induced by Approx. Zeeman Hamiltonian at different k divided by 0.5 * B_i\n')
f_de_test.write('#Band range: %4s %4s\n' % (bstart_g, bend_g))
s_dir = ['x','y','z','['+str(Bdir[0])+' '+str(Bdir[1])+' '+str(Bdir[2])+']']
f_cd = open("cd.out", "w")

for ik in range(nk_g):
  print('#At ik = ',ik,':')
  f_AM_diag.write('#At ik = %d:\n' % (ik))
  f_de.write('#At ik = %d:\n' % (ik))
  f_de_test.write('#At ik = %d:\n' % (ik))
  f_cd.write('#At ik = %d:\n' % (ik))
  
  for iB in range(4): # loop on directions
    print('Along '+s_dir[iB])
    sys.stdout.flush()
    f_AM_diag.write('#B field Along '+s_dir[iB]+':\n')
    f_de.write('#B field Along '+s_dir[iB]+':\n')
    f_de_test.write('#B field Along '+s_dir[iB]+':\n')
    f_cd.write('#B field Along '+s_dir[iB]+':\n')
  
    # Project to dir. Bdir_[iB]
    LB = np.einsum('i,iab->ab', Bdir_[iB], L[ik]) # along direction Bdir_[iB]
    SB = np.einsum('i,iab->ab', Bdir_[iB], S[ik]) # along direction Bdir_[iB]
    
    # Apply a magnetic field (suppose the band ordering is not changed)
    H = 0.5 * Bmag * (LB + gs*SB) # Zeeman Hamiltonian
    for ib in range(nb_l):
      H[ib,ib] = H[ib,ib] + e[ik,ib]
    eB,UB = LA.eigh(H) # new eigenvalues and eigenvectors of Hamiltonian H(Bi)
    UB_trunc = UB[:,bstart_g:bend_g]
      
    # Output Ap
    pB = np.einsum("ba,ibc,cd->iad", UB_trunc.conj(), p[ik,:,0:nb_l,0:nb_l], UB_trunc)
    ArcpB = np.einsum('i,iab->ab', Arc, pB)
    AlcpB = np.einsum('i,iab->ab', Alc, pB)
    dAp = np.real(ArcpB.conj() * ArcpB - AlcpB.conj() * AlcpB)
    CD = np.real(ArcpB.conj() * ArcpB - AlcpB.conj() * AlcpB) / np.real(ArcpB.conj() * ArcpB + AlcpB.conj() * AlcpB)
    if bstart_g < bCBM and bend_g > bCBM:
      for bv in range(0,bCBM-bstart_g):
        for bc in range(bCBM-bstart_g,bend_g-bstart_g):
          f_cd.write('bv, bc = %d, %d; DE = %.6f eV; CD: %.3e (dAp: %.3e)\n' % (bv, bc, (eB[bc+bstart_g]-eB[bv+bstart_g])*27.211386, CD[bv,bc], dAp[bv,bc]))
    f_cd.flush()
    
    # Output energy changes induced by Bext
    deB = (eB[bstart_g:bend_g] - e[ik,bstart_g:bend_g]) / (0.5*Bmag) # energy differences multiplied by 1 / (0.5 * B_i)
    np.savetxt(f_de, deB.reshape(1,-1), fmt='%.4f')
    f_de.flush()
    
    # Output diagonal elements of L, S and L+gs*S matrices
    LB_diag = np.einsum("ba,bc,ca->a", UB_trunc.conj(), LB, UB_trunc).real
    Si_diag = np.einsum("ba,ibc,ca->ia", UB_trunc.conj(), S[ik], UB_trunc).real
    if iB < 3:
      SB_diag = Si_diag[iB]
    else:
      SB_diag = np.einsum("ba,bc,ca->a", UB_trunc.conj(), SB, UB_trunc).real
    np.savetxt(f_AM_diag, np.concatenate((LB_diag, SB_diag, LB_diag+gs*SB_diag), axis=None).reshape(1,3*(bend_g-bstart_g)), fmt='%.4f')
    f_AM_diag.flush()
    
    if SOC:
      # Apply approxmiate Zeeman
      def apply_appr_Zeeman(ik, iB, gij):
        H = 0.5 * Bmag * np.einsum("i,ij,jab->ab", Bdir_[iB], gij, S[ik])
        for ib in range(nb_l):
          H[ib,ib] = H[ib,ib] + e[ik,ib]
        eB,_ = LA.eigh(H) # new eigenvalues and eigenvectors of Hamiltonian H(Bi)
        return eB
      
      deB = np.zeros((1,bend_g-bstart_g),np.float64)
      for ib in range(bend_g-bstart_g):
        for jb in range(ib+bstart_g+1,bend_g):
          if abs(e[ik][jb] - e[ik][ib+bstart_g]) > groupthr:
            break
        if jb == nb_l - 1:
          jb = nb_l
        # Apply approxmiate Zeeman
        eB = apply_appr_Zeeman(ik, iB, gij[ik,ib])
        # Output energy changes induced by Bext
        deB[0,ib:jb] = (eB[ib+bstart_g] - e[ik,ib+bstart_g]) / (0.5*Bmag) # energy differences multiplied by 1 / (0.5 * B_i)
      np.savetxt(f_de_test, deB, fmt='%.4f')
      f_de_test.flush()

f_de.close()
f_AM_diag.close()
f_de_test.close()
f_cd.close()
